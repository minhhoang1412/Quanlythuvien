﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using QuanLyThuVienAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuanLyThuVienAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ChitietmuonController : ControllerBase
    {
        public readonly QuanLyThuVienContext _context;
        public ChitietmuonController(QuanLyThuVienContext context)
        {
            _context = context;
        }
        [HttpGet]
        public async Task<IEnumerable<Chitietmuon>> GetAll()
        {
            return await _context.Chitietmuons.ToListAsync();
        }
        [HttpPost]
        public async Task<IActionResult> Createchitietmuon(Chitietmuon ckh)
        {
            if (ckh == null)
            {
                return BadRequest();
            }
            _context.Chitietmuons.Add(ckh);
            await _context.SaveChangesAsync();
            return StatusCode(201, ckh);
        }
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateChitietmuon(Chitietmuon bhud, int id)
        {
            if (id != bhud.Mapm)
            {
                return BadRequest();
            }
            _context.Chitietmuons.Update(bhud);
            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteChitietmuon(int id)
        {
            var kh = _context.Chitietmuons.Find(id);
            _context.Chitietmuons.Remove(kh);
            await _context.SaveChangesAsync();
            return StatusCode(200, kh);
        }
    }
}
