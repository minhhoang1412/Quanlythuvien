﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using QuanLyThuVienAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuanLyThuVienAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DocgiaController : ControllerBase
    {
        public readonly QuanLyThuVienContext _context;
        public DocgiaController(QuanLyThuVienContext context)
        {
            _context = context;
        }
        [HttpGet]
        public async Task<IEnumerable<Nguoithue>> GetAll()
        {
            return await _context.Nguoithues.ToListAsync();
        }
        [HttpPost]
        public async Task<IActionResult> CreateHDM(Nguoithue ckh)
        {
            if (ckh == null)
            {
                return BadRequest();
            }
            _context.Nguoithues.Add(ckh);
            await _context.SaveChangesAsync();
            return StatusCode(201, ckh);
        }
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateNguoithue(Nguoithue bhud, int id)
        {
            if (id != bhud.Madg)
            {
                return BadRequest();
            }
            _context.Nguoithues.Update(bhud);
            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteNguoithue(int id)
        {
            var kh = _context.Nguoithues.Find(id);
            _context.Nguoithues.Remove(kh);
            await _context.SaveChangesAsync();
            return StatusCode(200, kh);
        }
        [HttpGet("Search")]
        public async Task<IActionResult> SearchNguoithue(string namedg)
        {
            var kq = await _context.Nguoithues.Where(x => x.Tendg.Contains(namedg)).ToListAsync();
            return StatusCode(200, kq);
        }
        [HttpGet("SearchById")]
        public async Task<IActionResult> SearchIDNguoithue(int mdg)
        {
            var kq = await _context.Nguoithues.Where(x => x.Madg == mdg).ToListAsync();
            if(kq == null)
            {
                return StatusCode(400);
            }
            else
            {
                return StatusCode(200, kq);
            }
            
        }
    }
}
