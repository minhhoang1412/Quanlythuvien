﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using QuanLyThuVienAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuanLyThuVienAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HoadonmuonController : ControllerBase
    {
        public readonly QuanLyThuVienContext _context;
        public HoadonmuonController(QuanLyThuVienContext context)
        {
            _context = context;
        }
        [HttpGet]
        public async Task<IEnumerable<Hoadonmuon>> GetAll()
        {
            return await _context.Hoadonmuons.ToListAsync();
        }
        [HttpPost]
        public async Task<IActionResult> CreateHDM(Hoadonmuon ckh)
        {
            if (ckh == null)
            {
                return BadRequest();
            }
            _context.Hoadonmuons.Add(ckh);
            await _context.SaveChangesAsync();
            return StatusCode(201, ckh);
        }
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateHoadonmuon(Hoadonmuon bhud, int id)
        {
            if (id != bhud.Mapm)
            {
                return BadRequest();
            }
            _context.Hoadonmuons.Update(bhud);
            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteHoadonmuon(int id)
        {
            var kh = _context.Hoadonmuons.Find(id);
            _context.Hoadonmuons.Remove(kh);
            await _context.SaveChangesAsync();
            return StatusCode(200, kh);
        }
        [HttpGet("Search/{id}")]
        public async Task<IActionResult> SearchHoadonmuon(int idpm)
        {
            var kq = await _context.Hoadonmuons.Where(x => x.Mapm == idpm).ToListAsync();
            return StatusCode(200, kq);
        }
    }
}
