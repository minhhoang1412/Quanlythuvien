﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using QuanLyThuVienAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace QuanLyThuVienAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class KeSachController : ControllerBase
    {
        public readonly QuanLyThuVienContext _context; 
        public KeSachController(QuanLyThuVienContext context)
        {
            _context = context;
        }
        [HttpGet]
        public async Task<IEnumerable<Vitri>> GetAll()
        {
            return await _context.Vitris.ToListAsync();
        }

        [HttpPost]
        public async Task<IActionResult> Createvitri(Vitri ckh)
        {
            Console.WriteLine(ckh);
            if (ckh == null)
            {
                return BadRequest();
            }
            _context.Vitris.Add(ckh);
            await _context.SaveChangesAsync();
            return StatusCode(201, ckh);
        }
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateVitri(Vitri bhud, int id)
        {
            if (id != bhud.Mavt)
            {
                return BadRequest();
            }
            _context.Vitris.Update(bhud);
            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteVitri(int id)
        {
            var kh = _context.Vitris.Find(id);
            _context.Vitris.Remove(kh);
            await _context.SaveChangesAsync();
            return StatusCode(200, kh);
        }
        [HttpGet("Search")]
        public async Task<IActionResult> SearchVitri([FromQuery] string tvt)
        {
            var kq = await _context.Vitris.Where(x => x.Tenke.Contains(tvt)).ToListAsync();
            return StatusCode(200, kq);
        }
    }
}
