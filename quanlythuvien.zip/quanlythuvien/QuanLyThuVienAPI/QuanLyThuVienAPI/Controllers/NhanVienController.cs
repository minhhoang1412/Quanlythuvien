﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using QuanLyThuVienAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuanLyThuVienAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class NhanvienController : ControllerBase
    {
        public readonly QuanLyThuVienContext _context;
        public NhanvienController(QuanLyThuVienContext context)
        {
            _context = context;
        }
        [HttpGet]
        public async Task<IEnumerable<Nhanvien>> GetAll()
        {
            return await _context.Nhanviens.ToListAsync();
        }
        [HttpPost]
        public async Task<IActionResult> Create(Nhanvien ckh)
        {
            if (ckh == null)
            {
                return BadRequest();
            }
            _context.Nhanviens.Add(ckh);
            await _context.SaveChangesAsync();
            return StatusCode(201, ckh);
        }
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateNhanvien(Nhanvien bhud, int id)
        {
            if (id != bhud.Manv)
            {
                return BadRequest();
            }
            _context.Nhanviens.Update(bhud);
            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteNhanvien(int id)
        {
            var kh = _context.Nhanviens.Find(id);
            _context.Nhanviens.Remove(kh);
            await _context.SaveChangesAsync();
            return StatusCode(200, kh);
        }
        [HttpGet("Search")]
        public async Task<IActionResult> SearchNhanvien([FromQuery] string tvt)
        {
            var kq = await _context.Nhanviens.Where(x => x.Tennv.Contains(tvt)).ToListAsync();
            return StatusCode(200, kq);
        }
    }
}
