﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using QuanLyThuVienAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuanLyThuVienAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SachController : ControllerBase
    {
        public readonly QuanLyThuVienContext _context;
        public SachController(QuanLyThuVienContext context)
        {
            _context = context;
        }
        [HttpGet]
        public async Task<IEnumerable<Sach>> GetAll()
        {
            return await _context.Saches.ToListAsync();
        }
        [HttpGet("GetBook")]
        public async Task<IActionResult> GetInfoBook(int id)
        {
            var rel = (from book in _context.Saches
                       join typebook in _context.Theloais on book.Matl equals typebook.Matl
                       join posibook in _context.Vitris on book.Mavt equals posibook.Mavt
                       where book.Masach == id 
                       select new
                       {
                           idtl = typebook.Matl,
                           ntl = typebook.Tentl,
                           vt = posibook.Tenke,
                           idvt = posibook.Mavt,
                           book
                       }).FirstOrDefault();
            return StatusCode(200, rel);
        }
        [HttpPost]
        public async Task<IActionResult> Create(Sach ckh)
        {
            if (ckh == null)
            {
                return BadRequest();
            }
            _context.Saches.Add(ckh);
            await _context.SaveChangesAsync();
            return StatusCode(201, ckh);
        }
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateSach(Sach bhud, int id)
        {
            if (id != bhud.Masach)
            {
                return BadRequest();
            }
            _context.Saches.Update(bhud);
            await _context.SaveChangesAsync();
            return StatusCode(200, bhud);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteSach(int id)
        {
            var kh = _context.Saches.Find(id);
            _context.Saches.Remove(kh);
            await _context.SaveChangesAsync();
            return StatusCode(200, kh);
        }
        [HttpGet("Search")]
        public async Task<IActionResult> SearchSach([FromQuery] string keyword)
        {
            var kq = await _context.Saches.Where(x => x.Tensach.Contains(keyword)).ToListAsync();
            return StatusCode(200, kq);
        }
        [HttpGet("SearchType")]
        public async Task<IActionResult> SearchType(int id)
        {
            var kq = await _context.Saches.Where(x => x.Matl == id).ToListAsync();
            return StatusCode(200, kq);
        }
        [HttpGet("amb")]
        public async Task<IActionResult> GetAmountBook(int amount)
        {
            var rel = await (from book in _context.Saches
                       orderby book.Masach descending
                       select book).Take(amount).ToListAsync();
            return StatusCode(200, rel);
        }
        [HttpGet("vt")]
        public async Task<IActionResult> GetLocalBook(int idcl)
        {
            var kq = await _context.Saches.Where(x => x.Mavt == idcl).ToListAsync();
            return StatusCode(200, kq);
        }

    }
}
