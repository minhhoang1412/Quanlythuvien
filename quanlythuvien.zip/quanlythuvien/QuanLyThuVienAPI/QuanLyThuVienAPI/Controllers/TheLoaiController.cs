﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using QuanLyThuVienAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuanLyThuVienAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TheLoaiController : ControllerBase
    {
        public readonly QuanLyThuVienContext _context;
        public TheLoaiController(QuanLyThuVienContext context)
        {
            _context = context;
        }
        [HttpGet]
        public async Task<IEnumerable<Theloai>> GetAll()
        {
            return await _context.Theloais.ToListAsync();
        }
        [HttpPost]
        public async Task<IActionResult> CreateKhoachoc(Theloai ckh)
        {
            if (ckh == null)
            {
                return BadRequest();
            }
            _context.Theloais.Add(ckh);
            await _context.SaveChangesAsync();
            return StatusCode(201, ckh);
        }
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateTheloai(Theloai bhud, int id)
        {
            if (id != bhud.Matl)
            {
                return BadRequest();
            }
            _context.Theloais.Update(bhud);
            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteTheloai(int id)
        {
            var kh = _context.Theloais.Find(id);
            _context.Theloais.Remove(kh);
            await _context.SaveChangesAsync();
            return StatusCode(200, kh);
        }
        [HttpGet("Search")]
        public async Task<IActionResult> SearchTheloai([FromQuery] string tvt)
        {
            var kq = await _context.Theloais.Where(x => x.Tentl.Contains(tvt)).ToListAsync();
            return StatusCode(200, kq);
        }
    }
}
