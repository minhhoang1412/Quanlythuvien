﻿using System;
using System.Collections.Generic;

#nullable disable

namespace QuanLyThuVienAPI.Models
{
    public partial class Chitietmuon
    {
        public int Mapm { get; set; }
        public int? Mash { get; set; }
        public DateTime? Ngaythue { get; set; }
        public DateTime? Ngaytra { get; set; }
        public string Ghichu { get; set; }

        public virtual Hoadonmuon MapmNavigation { get; set; }
        public virtual Sach MashNavigation { get; set; }
    }
}
