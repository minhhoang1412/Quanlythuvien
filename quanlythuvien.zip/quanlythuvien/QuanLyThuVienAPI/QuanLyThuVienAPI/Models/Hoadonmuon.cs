﻿using System;
using System.Collections.Generic;

#nullable disable

namespace QuanLyThuVienAPI.Models
{
    public partial class Hoadonmuon
    {
        public int Mapm { get; set; }
        public int? Madg { get; set; }
        public int? Manv { get; set; }
        public string Tiencoc { get; set; }
        public DateTime? NgayMuon { get; set; }
        public DateTime? NgayDuKienTra { get; set; }
        public int? MaSach { get; set; }

        public virtual Nguoithue MadgNavigation { get; set; }
        public virtual Nhanvien ManvNavigation { get; set; }
        public virtual Chitietmuon Chitietmuon { get; set; }
    }
}
