﻿using System;
using System.Collections.Generic;

#nullable disable

namespace QuanLyThuVienAPI.Models
{
    public partial class Nguoithue
    {
        public Nguoithue()
        {
            Hoadonmuons = new HashSet<Hoadonmuon>();
        }

        public int Madg { get; set; }
        public string Tendg { get; set; }
        public string Phai { get; set; }
        public DateTime Namsinh { get; set; }
        public string Nghenghiep { get; set; }
        public DateTime Ngaycapthe { get; set; }
        public DateTime Ngayhethan { get; set; }
        public string Diachi { get; set; }

        public virtual ICollection<Hoadonmuon> Hoadonmuons { get; set; }
    }
}
