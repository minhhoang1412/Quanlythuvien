﻿using System;
using System.Collections.Generic;

#nullable disable

namespace QuanLyThuVienAPI.Models
{
    public partial class Nhanvien
    {
        public Nhanvien()
        {
            Hoadonmuons = new HashSet<Hoadonmuon>();
        }

        public int Manv { get; set; }
        public string Tennv { get; set; }
        public string Phai { get; set; }
        public string Diachi { get; set; }
        public string Dienthoai { get; set; }

        public virtual ICollection<Hoadonmuon> Hoadonmuons { get; set; }
    }
}
