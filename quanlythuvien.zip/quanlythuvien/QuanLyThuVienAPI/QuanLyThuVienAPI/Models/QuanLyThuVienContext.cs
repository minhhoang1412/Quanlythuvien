﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace QuanLyThuVienAPI.Models
{
    public partial class QuanLyThuVienContext : DbContext
    {
        public QuanLyThuVienContext()
        {
        }

        public QuanLyThuVienContext(DbContextOptions<QuanLyThuVienContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Chitietmuon> Chitietmuons { get; set; }
        public virtual DbSet<Hoadonmuon> Hoadonmuons { get; set; }
        public virtual DbSet<Nguoithue> Nguoithues { get; set; }
        public virtual DbSet<Nhanvien> Nhanviens { get; set; }
        public virtual DbSet<Sach> Saches { get; set; }
        public virtual DbSet<Theloai> Theloais { get; set; }
        public virtual DbSet<Vitri> Vitris { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Server=MINHHIEUPC\\SQLEXPRESS;Database=QuanLyThuVien;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");

            modelBuilder.Entity<Chitietmuon>(entity =>
            {
                entity.HasKey(e => e.Mapm)
                    .HasName("PK_CHITIETMUONS");

                entity.ToTable("CHITIETMUON");

                entity.Property(e => e.Mapm)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("MAPM");

                entity.Property(e => e.Ghichu)
                    .HasMaxLength(150)
                    .HasColumnName("GHICHU");

                entity.Property(e => e.Mash).HasColumnName("MASH");

                entity.Property(e => e.Ngaythue)
                    .HasColumnType("date")
                    .HasColumnName("NGAYTHUE");

                entity.Property(e => e.Ngaytra)
                    .HasColumnType("date")
                    .HasColumnName("NGAYTRA");

                entity.HasOne(d => d.MapmNavigation)
                    .WithOne(p => p.Chitietmuon)
                    .HasForeignKey<Chitietmuon>(d => d.Mapm)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CHITIETMUON_HOADONMUON");

                entity.HasOne(d => d.MashNavigation)
                    .WithMany(p => p.Chitietmuons)
                    .HasForeignKey(d => d.Mash)
                    .HasConstraintName("FK_CHITIETMUON_SACH");
            });

            modelBuilder.Entity<Hoadonmuon>(entity =>
            {
                entity.HasKey(e => e.Mapm);

                entity.ToTable("HOADONMUON");

                entity.Property(e => e.Mapm).HasColumnName("MAPM");

                entity.Property(e => e.Madg).HasColumnName("MADG");

                entity.Property(e => e.Manv).HasColumnName("MANV");

                entity.Property(e => e.Tiencoc)
                    .HasMaxLength(50)
                    .HasColumnName("TIENCOC");

                entity.HasOne(d => d.MadgNavigation)
                    .WithMany(p => p.Hoadonmuons)
                    .HasForeignKey(d => d.Madg)
                    .HasConstraintName("FK_HOADONMUON_NGUOITHUE");

                entity.HasOne(d => d.ManvNavigation)
                    .WithMany(p => p.Hoadonmuons)
                    .HasForeignKey(d => d.Manv)
                    .HasConstraintName("FK_HOADONMUON_NHANVIEN");
            });

            modelBuilder.Entity<Nguoithue>(entity =>
            {
                entity.HasKey(e => e.Madg)
                    .HasName("PK_DOCGIA");

                entity.ToTable("NGUOITHUE");

                entity.Property(e => e.Madg).HasColumnName("MADG");

                entity.Property(e => e.Diachi)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("DIACHI");

                entity.Property(e => e.Namsinh)
                    .HasColumnType("date")
                    .HasColumnName("NAMSINH");

                entity.Property(e => e.Ngaycapthe)
                    .HasColumnType("date")
                    .HasColumnName("NGAYCAPTHE");

                entity.Property(e => e.Ngayhethan)
                    .HasColumnType("date")
                    .HasColumnName("NGAYHETHAN");

                entity.Property(e => e.Nghenghiep)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("NGHENGHIEP");

                entity.Property(e => e.Phai)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("PHAI");

                entity.Property(e => e.Tendg)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("TENDG");
            });

            modelBuilder.Entity<Nhanvien>(entity =>
            {
                entity.HasKey(e => e.Manv);

                entity.ToTable("NHANVIEN");

                entity.Property(e => e.Manv).HasColumnName("MANV");

                entity.Property(e => e.Diachi)
                    .HasMaxLength(100)
                    .HasColumnName("DIACHI");

                entity.Property(e => e.Dienthoai)
                    .HasMaxLength(50)
                    .HasColumnName("DIENTHOAI");

                entity.Property(e => e.Phai)
                    .HasMaxLength(50)
                    .HasColumnName("PHAI");

                entity.Property(e => e.Tennv)
                    .HasMaxLength(100)
                    .HasColumnName("TENNV");
            });

            modelBuilder.Entity<Sach>(entity =>
            {
                entity.HasKey(e => e.Masach);

                entity.ToTable("SACH");

                entity.Property(e => e.Masach).HasColumnName("MASACH");

                entity.Property(e => e.Giathue)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("GIATHUE");

                entity.Property(e => e.Matl).HasColumnName("MATL");

                entity.Property(e => e.Mavt).HasColumnName("MAVT");

                entity.Property(e => e.Ngaymuasach)
                    .HasColumnType("date")
                    .HasColumnName("NGAYMUASACH");

                entity.Property(e => e.Ngonngu)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("NGONNGU");

                entity.Property(e => e.Nhaxuatban)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("NHAXUATBAN");

                entity.Property(e => e.Noidung)
                    .IsRequired()
                    .HasColumnType("text")
                    .HasColumnName("NOIDUNG");

                entity.Property(e => e.Sotrang).HasColumnName("SOTRANG");

                entity.Property(e => e.Tacgia)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("TACGIA");

                entity.Property(e => e.Tensach)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("TENSACH");

                entity.Property(e => e.Trangthai).HasColumnName("TRANGTHAI");

                entity.HasOne(d => d.MatlNavigation)
                    .WithMany(p => p.Saches)
                    .HasForeignKey(d => d.Matl)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_SACH_THELOAI");

                entity.HasOne(d => d.MavtNavigation)
                    .WithMany(p => p.Saches)
                    .HasForeignKey(d => d.Mavt)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_SACH_VITRI");
            });

            modelBuilder.Entity<Theloai>(entity =>
            {
                entity.HasKey(e => e.Matl);

                entity.ToTable("THELOAI");

                entity.Property(e => e.Matl).HasColumnName("MATL");

                entity.Property(e => e.Tentl)
                    .HasMaxLength(50)
                    .HasColumnName("TENTL");
            });

            modelBuilder.Entity<Vitri>(entity =>
            {
                entity.HasKey(e => e.Mavt);

                entity.ToTable("VITRI");

                entity.Property(e => e.Mavt).HasColumnName("MAVT");

                entity.Property(e => e.Tenke)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("TENKE");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
