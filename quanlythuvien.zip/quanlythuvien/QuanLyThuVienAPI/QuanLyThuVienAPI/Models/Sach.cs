﻿using System;
using System.Collections.Generic;

#nullable disable

namespace QuanLyThuVienAPI.Models
{
    public partial class Sach
    {
        public Sach()
        {
            Chitietmuons = new HashSet<Chitietmuon>();
        }

        public int Masach { get; set; }
        public int Matl { get; set; }
        public int Mavt { get; set; }
        public string Tensach { get; set; }
        public string Noidung { get; set; }
        public int Sotrang { get; set; }
        public string Tacgia { get; set; }
        public string Ngonngu { get; set; }
        public string Nhaxuatban { get; set; }
        public DateTime Ngaymuasach { get; set; }
        public string Giathue { get; set; }
        public bool Trangthai { get; set; }
        public int Soluong { get; set; }
        public string? LinkImg { get; set; }
        public string? Motangan { get; set; }

        public virtual Theloai MatlNavigation { get; set; }
        public virtual Vitri MavtNavigation { get; set; }
        public virtual ICollection<Chitietmuon> Chitietmuons { get; set; }
    }
}
