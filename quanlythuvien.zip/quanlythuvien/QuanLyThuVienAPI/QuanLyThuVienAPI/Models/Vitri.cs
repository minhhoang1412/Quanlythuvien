﻿using System;
using System.Collections.Generic;

#nullable disable

namespace QuanLyThuVienAPI.Models
{
    public partial class Vitri
    {
        public Vitri()
        {
            Saches = new HashSet<Sach>();
        }

        public int Mavt { get; set; }
        public string Tenke { get; set; }

        public virtual ICollection<Sach> Saches { get; set; }
    }
}
