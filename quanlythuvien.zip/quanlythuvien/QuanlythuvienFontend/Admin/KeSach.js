$(function(){
    $.ajax({
        
        type:'GET',
        url:'https://localhost:5001/api/KeSach',
        success:function(data){
            var showList;
            console.log('success',data);
            // data.forEach(element => {
            //     showList += `<tr>`;
            //      showList += `<td> ${element['tenke']} </td>`;
            //      showList += `<td><button class="btn btn-success" onclick="suaks(${element})">Sửa</button>
            //      <button class="btn btn-danger" onclick="xoaks(${element['mavt']})">Xóa</button>
            //      </td>` 
            //      showList += `</tr>`; 
                         
            // });
            for(var element = 0 ; element < data.length;element++){
                showList += `<tr>`;
                 showList += `<td> ${data[element]['tenke']} </td>`;
                 showList += `<td><button class="btn btn-success" onclick="suaks(${element})">Sửa</button>
                 <button class="btn btn-danger" onclick="xoaks(${data[element]['mavt']})">Xóa</button>
                 </td>` 
                 showList += `</tr>`;
                 

            }
            $('#showkesach').html(showList);
            

        }
    })
});
function SentData(urlsent,methodsent,id){
    var dataf = {
        "tenke":$("#nameKeSachxx").val()
    };
    if(id !== null){
        urlsent =`${urlsent}/${id}` ;
        dataf = {
            "tenke":$("#nameKeSachxx").val(),
            "mavt":$("#saveid").val()
        };
    }
    $.ajax({
        
        url:urlsent,
        type:methodsent,
        data:dataf,
        contentType:'application/json',
        data:JSON.stringify(dataf),
    }).done(function(data){
        console.log(data);
        alert("Thao tác thành công");
        location.reload();
        console.log(dataf)
        console.log(id);
    }).fail(function(){
        alert("Thao tác thất bại");
        console.log(dataf)
        console.log(id);
    })

}
function themks(req,response,next)
{
    SentData('https://localhost:5001/api/KeSach','POST',null);
}
function suaks(idks)
{
    $.ajax({
        type:'GET',
        url:'https://localhost:5001/api/KeSach'
    }).done(function(data){
        console.log(idks)
      
        document.getElementById("btnthemks").style.display = "none";
        document.getElementById("btnsuaks").style.display = "block";
        $("#nameKeSachxx").val(data[idks]['tenke']);
        $("#saveid").val(data[idks]['mavt']);
    }); 
}
function xacnhansuaks(){
    var getID = $("#saveid").val();
    SentData(`https://localhost:5001/api/KeSach`,'Put',getID);
    
}
function xoaks(idks){
    $(function(){
        $.ajax({
            type:'DELETE',
            url:`https://localhost:5001/api/KeSach/${idks}`
        }).done(function(){
            alert("Xóa dữ liệu thành công");
            location.reload();
        }).fail(function(){
            alert("Xóa dữ liệu thất bại");
        })
    });

}
