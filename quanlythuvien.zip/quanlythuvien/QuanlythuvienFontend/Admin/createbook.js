$.ajax({
  type: "GET",
  url: "https://localhost:5001/api/theloai",
  success: function (data) {
    var showList;
    console.log("success", data);
  },
}).done(function (data) {
  var optionsl = ``;
  var selecttheloai = document.getElementById("theloaisach");
  console.log(selecttheloai);
  optionsl += `<option id="selectedbook"> Chọn thể loại... </option>`;
  data.forEach((element) => {
    optionsl += `<option value="${element["matl"]}"> ${element["tentl"]} </option>`;
  });
  selecttheloai.innerHTML = optionsl;
});

$.ajax({
  type: "GET",
  url: "https://localhost:5001/api/kesach",
  success: function (data) {
    var showList;
   // console.log("success", data);
  },
}).done(function (data) {
  var optionsl = ``;
  var selecvt = document.getElementById("vitrisach");
  console.log(selecvt);
  optionsl += `<option id="selectekesach"> Chọn thể loại... </option>`;
  data.forEach((element) => {
    optionsl += `<option value="${element["mavt"]}"> ${element["tenke"]} </option>`;
  });
  selecvt.innerHTML = optionsl;
});
// ======create=======

function SentData(urlsent, methodsent, id) {
  var desc = CKEDITOR.instances['ContentBooks'].getData();
  console.log(desc);
  var dataf = {
    matl:  $('#theloaisach').find(":selected").attr("value"),
    mavt:  $('#vitrisach').find(":selected").attr("value"),
    tensach : $("#tensach").val(),
    sotrang : $("#soluongtrang").val(),
    tacgia : $("#tacgia").val(),
    ngonngu : $('#ngonngu').find(":selected").text(),
    nhaxuatban : $("#NhaXuatBan").val(),
    ngaymuasach : $("#NgayMuaSach").val(),
    noidung : CKEDITOR.instances['ContentBooks'].getData(),
    soluong : $("#soluongsach").val(),
    giathue : $("#GiaThue").val(),
    trangthai :  Boolean($("input[type='radio']:checked").val()),
    linkimg :  $("#anhmieuta").val(),
    motangan:$("#motangantext").val()

  };
  if (id !== null) {
    urlsent = `${urlsent}/${id}`;
    dataf = {
      tenke: $("#nameKeSachxx").val(),
      mavt: $("#saveid").val(),
      trangthai 
    };
  }
  $.ajax({
    url: urlsent,
    type: methodsent,
    data: dataf,
    contentType: "application/json",
    data: JSON.stringify(dataf),
  })
    .done(function (data) {
      //console.log(data);
      alert("Thao tác thành công");
      console.log(dataf);;
      window.location.replace("sach.html");
    })
    .fail(function () {
      alert("Thao tác thất bại");
      console.log(dataf);

    });
}
function themsach() {
  SentData("https://localhost:5001/api/Sach", "POST", null);
//  window.location="sach.html";
   
}
function suaks(idks) {
  $.ajax({
    type: "GET",
    url: "https://localhost:5001/api/KeSach",
  }).done(function (data) {
    console.log(idks);

    document.getElementById("btnthemks").style.display = "none";
    document.getElementById("btnsuaks").style.display = "block";
    $("#nameKeSachxx").val(data[idks]["tenke"]);
    $("#saveid").val(data[idks]["mavt"]);
  });
}
function xacnhansuaks() {
  var getID = $("#saveid").val();
  SentData(`https://localhost:5001/api/KeSach`, "Put", getID);
}
function xoaks(idks) {
  $(function () {
    $.ajax({
      type: "DELETE",
      url: `https://localhost:5001/api/KeSach/${idks}`,
    })
      .done(function () {
        alert("Xóa dữ liệu thành công");
        location.reload();
      })
      .fail(function () {
        alert("Xóa dữ liệu thất bại");
      });
  });
}
