$(function () {
  $.ajax({
    type: "GET",
    url: "https://localhost:5001/api/Docgia",
  }).done(function (data) {
    console.log(data);
    for (var element = 0; element < data.length; element++) {
      var showList;
      showList += `<tr>`;
      showList += `<td> ${data[element]["tendg"]} </td>`;
      showList += `<td> ${data[element]["phai"]} </td>`;
      var startDate = data[element]["namsinh"].split("T"); ;
      showList += `<td> ${startDate[0]} </td>`;
      showList += `<td> ${data[element]["nghenghiep"]} </td>`;
      var CT = data[element]["ngaycapthe"].split("T"); 
      showList += `<td> ${CT[0]} </td>`;
      var HH = data[element]["ngayhethan"].split("T");
      showList += `<td> ${HH[0]} </td>`;
      showList += `<td> ${data[element]["diachi"]} </td>`;
      showList += `<td><button class="btn btn-success" data-toggle="modal" data-target="#exampleModal" onclick="suanv(${element})">Sửa</button>
             <button class="btn btn-danger" onclick="xoatl(${data[element]["madg"]})">Xóa</button>
             </td>`;
      showList += `</tr>`;
    }
    $("#showData").html(showList);
  });
});
function SentData(urlsent, methodsent, id) {
  var dataf = {
    tendg: $("#tendocgia").val(),
    phai: $("input[type='radio']:checked").val(),
    nghenghiep: $("#nghenghiepdg").val(),
    ngayhethan: $("#ngaythehethan").val(),
    ngaycapthe: $("#ngaycapthedg").val(),
    namsinh: $("#namsinhdg").val(),
    diachi: $("#diachidg").val(),
  };
  if (id !== null) {
    urlsent = `${urlsent}/${id}`;
    dataf = {
      madg: $("#saveid").val(),
      tendg: $("#tendocgia").val(),
      phai: $("input[type='radio']:checked").val(),
      nghenghiep: $("#nghenghiepdg").val(),
      ngayhethan: $("#ngaythehethan").val(),
      ngaycapthe: $("#ngaycapthedg").val(),
      namsinh: $("#namsinhdg").val(),
      diachi: $("#diachidg").val(),
    };
  }
  $.ajax({
    url: urlsent,
    type: methodsent,
    data: dataf,
    contentType: "application/json",
    data: JSON.stringify(dataf),
  })
    .done(function (data) {
      console.log(data);
      alert("Thao tác thành công");
      location.reload();
      console.log(dataf);
      console.log(id);
    })
    .fail(function () {
      alert("Thao tác thất bại");
      console.log(dataf);
      console.log(id);
    });
}
function showbtnsave() {
  document.getElementById("btnthem").style.display = "block";
  document.getElementById("btnsua").style.display = "none";
}
function themnv() {
  SentData("https://localhost:5001/api/Docgia", "POST", null);
}
function suanv(idtl) {
  $.ajax({
    type: "GET",
    url: "https://localhost:5001/api/Docgia",
  }).done(function (data) {
    //console.log(idks)

    document.getElementById("btnthem").style.display = "none";
    document.getElementById("btnsua").style.display = "block";
    $("#saveid").val(data[idtl]["madg"]);
    $("#tendocgia").val(data[idtl]["tendg"]);
    $("input[name=gender][value=" + data[idtl]["phai"] + "]").prop(
      "checked",
      true
    );
    $("#nghenghiepdg").val(data[idtl]["nghenghiep"]);
    var hh = data[idtl]["ngayhethan"].split("T"); 
    var ct = data[idtl]["ngaycapthe"].split("T"); 
    $("#ngaythehethan").val(hh[0]);
    $("#ngaycapthedg").val(ct[0]);
    var startDate = data[idtl]["namsinh"].split("T"); ;
    console.log(startDate);
    $("#namsinhdg").val(startDate[0]);
    $("#diachidg").val(data[idtl]["diachi"]);
  });
}
function xacnhansuanv() {
  var getID = $("#saveid").val();
  SentData(`https://localhost:5001/api/Docgia`, "Put", getID);
}
function xoatl(idtl) {
  $(function () {
    $.ajax({
      type: "DELETE",
      url: `https://localhost:5001/api/Docgia/${idtl}`,
    })
      .done(function () {
        alert("Xóa dữ liệu thành công");
        location.reload();
      })
      .fail(function () {
        alert("Xóa dữ liệu thất bại");
      });
  });
}
