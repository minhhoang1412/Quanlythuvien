$(function(){
    $.ajax({
        type:'GET',
        url:'https://localhost:5001/api/nhanvien'
    }).done(function(data){
        console.log(data);
        for(var element = 0 ; element < data.length;element++){
            var showList;
            showList += `<tr>`;
             showList += `<td> ${data[element]['tennv']} </td>`;
             showList += `<td> ${data[element]['diachi']} </td>`;
             showList += `<td> ${data[element]['dienthoai']} </td>`;
             showList += `<td> ${data[element]['phai']} </td>`;
             showList += `<td><button class="btn btn-success" data-toggle="modal" data-target="#exampleModal" onclick="suanv(${element})">Sửa</button>
             <button class="btn btn-danger" onclick="xoatl(${data[element]['manv']})">Xóa</button>
             </td>` 
             showList += `</tr>`;
             
    
        }
        $('#showData').html(showList);
    })
    

});
function SentData(urlsent,methodsent,id){
    var dataf = {
        "tennv":$("#tennhanvien").val(),
        "diachi":$("#dichinhanvien").val(),
        "dienthoai":$("#sdtnhanvien").val(),
        "phai":$("input[type='radio']:checked").val()


    };
    if(id !== null){
        urlsent =`${urlsent}/${id}` ;
        dataf = {
            "manv":$("#saveid").val(),
            "tennv":$("#tennhanvien").val(),
            "diachi":$("#dichinhanvien").val(),
            "dienthoai":$("#sdtnhanvien").val(),
            "phai":$("input[type='radio']:checked").val()
        };
    }
    $.ajax({
        
        url:urlsent,
        type:methodsent,
        data:dataf,
        contentType:'application/json',
        data:JSON.stringify(dataf),
    }).done(function(data){
        console.log(data);
        alert("Thao tác thành công");
        location.reload();
        console.log(dataf)
        console.log(id);
    }).fail(function(){
        alert("Thao tác thất bại");
        console.log(dataf)
        console.log(id);
    })

}
function showbtnsave(){
    document.getElementById("btnthem").style.display = "block";
    document.getElementById("btnsua").style.display = "none";

}
function themnv()
{
    SentData('https://localhost:5001/api/nhanvien','POST',null);
}
function suanv(idtl)
{
    $.ajax({
        type:'GET',
        url:'https://localhost:5001/api/nhanvien'
    }).done(function(data){
        //console.log(idks)
      
        document.getElementById("btnthem").style.display = "none";
        document.getElementById("btnsua").style.display = "block";
        $("#saveid").val(data[idtl]['manv']);
        $("#tennhanvien").val(data[idtl]['tennv']);
        $("#dichinhanvien").val(data[idtl]['diachi']);
        $("#sdtnhanvien").val(data[idtl]['dienthoai']);
        $("input[name=gender][value=" + data[idtl]['phai'] + "]").prop('checked', true)
     
    }); 
}
function xacnhansuanv(){
    var getID = $("#saveid").val();
    SentData(`https://localhost:5001/api/nhanvien`,'Put',getID);
    
}
function xoatl(idtl){
    $(function(){
        $.ajax({
            type:'DELETE',
            url:`https://localhost:5001/api/nhanvien/${idtl}`
        }).done(function(){
            alert("Xóa dữ liệu thành công");
            location.reload();
        }).fail(function(){
            alert("Xóa dữ liệu thất bại");
        })
    });

}